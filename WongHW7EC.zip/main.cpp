//Bryant Wong
//CSCI 2421 Homework 7

#include "Customer.h"
#include "BankSimulation.h"


int main()
{
	BankSimulation Simulation;		//create an instance of BankSimulation named simulation
	Simulation.runSimulation();		//run the simulation
	std::cin.get();					//pause

}